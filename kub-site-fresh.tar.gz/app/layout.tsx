import type { Metadata } from "next";
import { Geist, Geist_Mono, Manrope, Inter } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ConsentBanner from "@/components/ui/ConsentBanner"; // ✅ Новый импорт

// Подключение шрифтов
const geistSans = Geist({ subsets: ["latin", "cyrillic"], variable: "--font-geist-sans" });
const geistMono = Geist_Mono({ subsets: ["latin", "cyrillic"], variable: "--font-geist-mono" });
const manrope = Manrope({ subsets: ["latin", "cyrillic"], variable: "--font-manrope" });
const inter = Inter({ subsets: ["latin", "cyrillic"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "ООО «КУБ» — Гранты, Сколково, налоговые льготы",
  description: "Помогаем получить резидентство Сколково, гранты до 30 млн ₽ и снизить налоговую нагрузку. Комплексное сопровождение инновационных проектов.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" className={`${geistSans.variable} ${geistMono.variable} ${manrope.variable} ${inter.variable}`}>
      <body className="font-sans antialiased bg-white text-gray-900 dark:bg-kub-navy dark:text-white">
        <Header />
        <main className="min-h-screen">
          {children}
        </main>
        <Footer />
        {/* ✅ Баннер согласия на обработку данных и cookie */}
        <ConsentBanner />
      </body>
    </html>
  );
}